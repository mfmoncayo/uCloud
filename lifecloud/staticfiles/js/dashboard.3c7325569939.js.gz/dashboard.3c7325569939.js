$(document).ready(function() {
  $('.logo').hover(function() {
    $(this).attr('src', 'logo2.jpeg');
    $(this).attr('src', 'logo.jpeg');
  });
});
