$(document).ready(function() {
  $('.logo').hover(function() {
    $(this).attr('src', '../../static/dist/images/logo2.jpg');
  });
});
